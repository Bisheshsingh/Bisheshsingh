package com.example.shopo.loginSignup;

public class PublicVariables {

    public static Boolean logindone = false;
    public static int loggedinnum = 0;
    public static String phoneofloggedin ;


}
